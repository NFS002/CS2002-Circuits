/*GLOBALS*/

/* This number (1000000) was chosen as the runtime upper limit because computing truth tables and timeseries for any longer times
  would signifiicantly reduce performance. */
const unsigned int max_circuit_time = 1000000;
/*If every node in the circuit was a wire, given the runtime limit, there could be a maximum of
 Log2(max_circuit_time) = Log10(max_circuit_time)/Log10(2) nodes in the circuit, so therfore this number (20) was chosen as the maximum circut size
 C99 does not have a log2 function, so we must convrert to log10. I have chosen to precompute
 this number, and round down to the closest integer, so as to improve performance of the program, rather than computing it every time it is used. */
const unsigned int circuit_size = 20;

const unsigned int min_circuit_time = 6;

unsigned int curr_circuit_time = 0;

unsigned int circuit_run_time;


typedef struct CircuitNode
{
  int state; // This attribute is used in case of asynchronous simulation
  char* id;
  char* func;
	struct CircuitNode* out;
	struct CircuitNode* inp_1;
  struct CircuitNode* inp_2;
	unsigned int states[max_circuit_time]; // This attribute is used in case of synchronous simulation
} CircuitNode;

CircuitNode* circuit[circuit_size];

void processLine(char* str, unsigned int line_num);
unsigned int splitString(char str[], char* dl, char** res);
void trimString(char* s);
int is_empty(const char *s);
void append(CircuitNode* new_node);
CircuitNode* findNodebyId(char* id);
CircuitNode* makeNode(char* id, char* func);
void printCircuit( void );
void initCircuit( void );
void printNode( CircuitNode* node );
void printTruthTable( bool reset );
void printCircuitInputs( void );
void decimalToBinaryArray(int decimal, int bin[], int numBits);
void initializeCircuitInputs(unsigned int i, bool reset, bool synchronous);
void simulateCircuit(unsigned int i, bool reset, bool synchronous);
void incrementCircuit(bool synchronous);
unsigned int getGateOutput(CircuitNode* gate, bool synchronous);
void printTimeseries(bool synchronous);
unsigned int countInputs( void );
void setCircuitRunTime( void );
void freeCircuit( void );
bool isCircuitComplete( void );
